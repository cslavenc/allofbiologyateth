function funkyUse()
funky_SameFunc()
funkyFolder.groovy()
funkyClass.classyFunk()
end

function funky_SameFunc()
disp('Funky calling SameFunc');
end