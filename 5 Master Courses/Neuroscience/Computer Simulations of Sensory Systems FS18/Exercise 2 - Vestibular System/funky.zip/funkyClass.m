classdef funkyClass
    
    methods(Static)
        function classyFunk()
            disp('Classy function in funkyClass');
        end
    end
end