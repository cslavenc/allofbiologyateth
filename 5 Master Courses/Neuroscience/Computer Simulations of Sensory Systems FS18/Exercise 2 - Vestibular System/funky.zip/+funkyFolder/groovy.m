function groovy()
disp('Groovy in funkyFolder');