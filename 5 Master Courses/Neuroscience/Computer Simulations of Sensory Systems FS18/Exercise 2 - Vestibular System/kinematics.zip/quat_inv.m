%QUAT_INV	Quaternion inversion
%	function p=quat_inv(q);
%	Calculates the inverse unit-quaternion.
%
%	JH, ThH, Version 1.2
%	Jan-96
%
% ********************************************************************
%Program Structure:
%\quat_inv				{in(1): ['q;'], out(1): ['q_inv']}
%	\qconj			{in(1): ['q'], out(1): ['p']}
%*****************************************************************
function q_inv=quat_inv(q);

[nq mq]=size(q);

if (mq~=3)&(mq~=4)
  error('input argument must have 3 or 4 columns');
end

if (mq==3)
	q_inv = -q;
else
	n=sum(q.^2')';
	p=qconj(q);
	q_inv=[p(:,1)./n p(:,2)./n p(:,3)./n p(:,4)./n];
end

