% QCONJ	calculates the conjugate of a quaternion.
%	P = QCONJ(Q) is the conjugate of quaternion Q. Also valid
%	if Q is a matrix with each row a quaternion or the vector
%	part of a q.
%
%	Joachim Heimberger, ca. 1993
%Program Structure:
%\qconj				{in(1): ['q'], out(1): ['p']}
%*****************************************************************
function p=qconj(q)

[nq mq]=size(q);

if (mq~=3)&(mq~=4)
  error('input argument must have 3 or 4 columns');
end
if (mq==3)
  q=[zeros(nq,1),q];
end

p=[q(:,1), -q(:,2:4)];
