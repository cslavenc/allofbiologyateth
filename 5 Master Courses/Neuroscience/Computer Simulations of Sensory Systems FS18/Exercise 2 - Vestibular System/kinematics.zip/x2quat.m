%X2QUAT	Conversions from other coordinates to quaternions
%	Call: Quat = x2quat2(data_in, data_type)
%	
%	quat_in ... output quaternion (in 3 columns)
%	data_in ... input data, usually in the form [T V H]
%	data_type ... can be:
%		[chair ... Zurich turntable position - Not implemented yet!]
%       bird ... MiniBird angles
%		deg ..... axis angle, i.e. quaternion expressed in degree for each component
%		fick .... Fick angles (in degree)
%		gimbal .. (Hess-)gimbal angles
%		helm .... Helmholz angles
%		rot_mat ..... rotation matrix
%		rot_vec ..... rotation vector (returns data as cell-array)
%		space ... direction in space (need not be normalized). The quaternion with 0 torsion is chosen.
%		test .... program test. The first value of "data_in" [as quaternion] is used for generation of the test-data
%
% 	Notes:
% 	Conversions of "fick", "gimbal", "helm", "rot_mat" currently go through "rot_vec", 
%		and could probably be simplified.
%
%	ThH, Jan-2006
%	Ver 1.05
% ********************************
%Program Structure:
%\x2quat				{in(2): ['data_in', 'data_type'], out(1): ['Quat']}
%	\normalize_v			{in(1): ['in_vector'], out(1): ['norm_vector']}
%	\quat2x			{in(3): ['quat_in', 'new_type', 'distance'], out(1): ['Result']}
%		\quat2x>>
%	\x2quat>>
%*****************************************************************


function Quat = x2quat(data_in, data_type)

in.data = data_in;
% Check and adjust the input:
if strcmp(data_type, 'rot_mat')
	in.num = length(in.data);
else
	if size(in.data,2) ~= 3		% if "in.data" is input as a column-matrix
		in.data = in.data';		% transpose it	
		if size(in.data, 2) ~= 3
			disp(['The input in ' upper(mfilename) ' requires data with 3 columns!']);
		else
			disp('Data have been transposed');
		end
	end
	in.num = size(data_in, 1);
end

% Here the conversions take place:
switch data_type
	case 'chair'
		disp([upper (mfilename) ': Option ' upper(data_type) ' is not implemented. Sorry!']);
		Result = [];

	case 'deg'
		alpha = mod(in.data,360)*pi/180;
		Quat = sin(alpha/2).*sign(sin(alpha));

	case 'fick_new'
% 		in.data(in.data<0) = in.data(in.data<0)+360;
		in.data = in.data*pi/360;
		[cp, cf, ct] = deal(cos(in.data(:,1)), cos(in.data(:,2)), cos(in.data(:,3)));
		[sp, sf, st] = deal(sin(in.data(:,1)), sin(in.data(:,2)), sin(in.data(:,3)));

		Quat = [ sp.*cf.*ct - cp.*sf.*st, cp.*sf.*ct + sp.*cf.*st, cp.*cf.*st - sp.*sf.*ct ];
		% 		% Check: q_length must be exactly "1"
		% 		quat_full = [cp.*cf.*ct + sp.*sf.*st Quat];
		% 		q_length = sum(quat_full.^2, 2)
		% 		quat2deg(sqrt(sum(Quat.^2,2)))
% x_in = [180 1 -180; 180 1 180]; quat2x(x2quat(x_in, 'fick'), 'gaze'), quat2x(x2quat(x_in, 'fick_old'), 'gaze')		
		% Old version, which goes through rotation vectors
	case 'fick'
		rot = zeros(size(in.data));		% allocate memory
		Mat = tan( in.data*pi/360 );	% convert to radian
		clear in.data;

		% Determine the rotation-vector:
		mult = 1 ./ (1+ prod(Mat,2));
		rot(:,1) = mult.*( Mat(:,1) - prod(Mat(:,[2 3]),2));
		rot(:,2) = mult.*( Mat(:,2) + prod(Mat(:,[3 1]),2));
		rot(:,3) = mult.*( Mat(:,3) - prod(Mat(:,[1 2]),2));

		Quat = x2quat(rot, 'rot_vec');

	case 'helm_new'
		in.data = in.data*pi/360;
		[cp, cf, ct] = deal(cos(in.data(:,1)), cos(in.data(:,2)), cos(in.data(:,3)));
		[sp, sf, st] = deal(sin(in.data(:,1)), sin(in.data(:,2)), sin(in.data(:,3)));

		Quat = [ sp.*cf.*ct + cp.*sf.*st, cp.*sf.*ct + sp.*cf.*st, cp.*cf.*st - sp.*sf.*ct ];
		% 		% Check: q_length must be exactly "1"
		% 		quat_full = [cp.*cf.*ct - sp.*sf.*st Quat];
		% 		q_length = sum(quat_full.^2, 2)

	case 'helm'
		rot = zeros(size(in.data));		% allocate memory
		Mat = tan( in.data*pi/360 );	% convert to radian
		clear in.data;

		% Determine the rotation-vector:
		mult = 1 ./ (1-prod(Mat,2));
		rot(:,1) = mult.*( Mat(:,1) + prod(Mat(:,[2 3]),2));
		rot(:,2) = mult.*( Mat(:,2) + prod(Mat(:,[3 1]),2));
		rot(:,3) = mult.*( Mat(:,3) - prod(Mat(:,[1 2]),2));

		Quat = x2quat(rot, 'rot_vec');

	case 'gimbal'
		rot = zeros(size(in.data));		% allocate memory
		Mat = tan( in.data*pi/360 );	% convert to radian
		clear in.data;

		% Determine the rotation-vector:
		mult = 1 ./ (1-prod(Mat,2));
		rot(:,1) = mult.*( Mat(:,1) - prod(Mat(:,[2 3]),2));
		rot(:,2) = mult.*( Mat(:,2) + prod(Mat(:,[3 1]),2));
		rot(:,3) = mult.*( Mat(:,3) + prod(Mat(:,[1 2]),2));

		Quat = x2quat(rot, 'rot_vec');

	case 'rot_vec'
		l_rot = sqrt(sum(in.data.^2,2));	% l_rot = tan(alpha/2)
		tan2sin = 1./sqrt(1+l_rot.^2);		% cos = 1/sqrt(1+tan^2)
		Quat = (tan2sin * ones(1,3)) .* in.data;

	case 'rot_mat'
		% rho = acos( (R(1,1)+R(2,2)+R(3,3)-1) / 2 );	% The angle of rotation		
		Quat = zeros(in.num, 3);	% allocate memory		
		for ii = 1:in.num
			R = in.data{ii};
			rot = [R(3,2)-R(2,3) R(1,3)-R(3,1) R(2,1)-R(1,2)] / (1 + trace(R));
			Quat(ii,:) = x2quat(rot, 'rot_vec');
		end

	case 'space'
		zero_gaze = repmat([1 0 0], in.num, 1);
		gaze_norm = normalize_v(in.data);

		alpha = acos(dot(zero_gaze, gaze_norm,2));	% Magnitude of rotation
		direction = normalize_v(cross(zero_gaze, gaze_norm,2));	% Direction		
		Quat = direction .* repmat(sin(alpha/2),1,3);	

	case 'bird'
		rot = zeros(size(in.data));		% allocate memory
		Mat = tan( in.data*pi/360 );	% convert to radian
		clear in.data;

		% Determine the rotation-vector:
		% Note: the "-1" is because MiniBird uses passive rotations
		mult = (-1) ./ (1- prod(Mat,2));
		rot(:,1) = mult.*( Mat(:,1) + prod(Mat(:,[2 3]),2));
		rot(:,2) = mult.*( Mat(:,2) - prod(Mat(:,[3 1]),2));
		rot(:,3) = mult.*( Mat(:,3) + prod(Mat(:,[1 2]),2));

		Quat = x2quat(rot, 'rot_vec');

	case 'test'
		% The results are tested by converting a number of inputs to the
		% required format, and then back-converting them to quaternions

		quat_test = in.data(1);
		test_in = [quat_test 0 0; ...
				0 quat_test 0; ...
				0 0 quat_test; ...
				0 0 0; ...
				0 quat_test quat_test];
		all_types = {'deg', 'fick', 'gaze', 'gimbal', 'helm', 'rot_mat', 'rot_vec', 'screen', 'sphere'};
		for ii = 1:length(all_types)
			disp('------------------------------');
			disp(all_types{ii});

			% Convert to quaternions ...
			if strcmp(all_types{ii}, 'screen') | strcmp(all_types{ii}, 'sphere') 
				distance = 100;
				eval(['Result_2q = quat2x(test_in,   ''' all_types{ii} ''', distance)']);
			else
				eval(['Result_2q = quat2x(test_in,   ''' all_types{ii} ''')']);
			end
			% ... and back:
			if strcmp(all_types{ii}, 'gaze') | strcmp(all_types{ii}, 'screen') | strcmp(all_types{ii}, 'sphere') 
				Result_fq = x2quat(Result_2q, 'space')
			else				
				eval(['Result_fq = x2quat(Result_2q, ''' all_types{ii} ''')']);
			end
			pause
		end			

	otherwise
		error([' No option ' upper(data_type) ' in ' upper(mfilename)]);
end
