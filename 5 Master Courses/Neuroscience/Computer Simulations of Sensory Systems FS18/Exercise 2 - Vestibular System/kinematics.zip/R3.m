%R3	Rotation matrix for rotation about the z-axis
%	function R = r3(theta)
%
%	This function calculates the active rotation matrix for rotation
%	about e3. 'theta' is entered in degree.
%
%	ThH, 1994
%	Version 1.0
%
%*****************************************************************
%Program Structure:
%\r3				{in(1): ['theta'], out(1): ['R']}
%*****************************************************************



function R = r3(theta)

% convert from degrees into radian:
theta = theta * pi/180;

R =	[	cos(theta)	-sin(theta)	0
		sin(theta)	cos(theta)	0
		0			0	1];
