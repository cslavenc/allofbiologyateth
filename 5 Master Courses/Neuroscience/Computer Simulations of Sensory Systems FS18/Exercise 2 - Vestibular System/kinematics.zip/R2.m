%R2	Rotation matrix for rotation about the y-axis
%	function R = r2(phi)
%
%	This function calculates the active rotation matrix for rotation
%	about e2. 'phi' is entered in degree.
%
%	ThH, 1994
%	Version 1.0
%
%*****************************************************************
%Program Structure:
%\r2				{in(1): ['phi'], out(1): ['R']}
%*****************************************************************



function R = r2(phi)

% convert from degrees into radian:
phi = phi * pi/180;

R = 	[	cos(phi)		0			sin(phi)
		0			1			0
		-sin(phi)		0			cos(phi) ];
