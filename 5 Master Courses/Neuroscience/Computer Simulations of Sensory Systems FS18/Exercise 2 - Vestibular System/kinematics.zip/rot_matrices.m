%ROT_MATRICES	Calculates (symbolic) Fick, Helmholtz, and (Hess)Gimbal
%	Matrices, ZurichTurntable
%
%	ThH, Oct-2003
%	Ver 1.1
% *****************************************************************
%Program Structure:
%\rot_matrices				{script}
%*****************************************************************



syms Rx Ry Rz theta phi psi theta2

% Define the simple rotation matrices
Rx = [1 0 0
   0 cos(psi) -sin(psi)
   0 sin(psi) cos(psi)];
Ry = [cos(phi)  0 sin(phi)
   0 1 0
   -sin(phi) 0 cos(phi)];
Rz = [cos(theta) -sin(theta) 0
   sin(theta) cos(theta) 0
   0 0 1];

Rz2 = [cos(theta2) -sin(theta2) 0
   sin(theta2) cos(theta2) 0
   0 0 1];

% Calculate the complex ones
R_Fick = Rz * Ry * Rx
R_Helmholtz = Ry * Rz * Rx
R_Gimbal = Rz * Rx * Ry
R_htt = Rz2*Rx*Rz