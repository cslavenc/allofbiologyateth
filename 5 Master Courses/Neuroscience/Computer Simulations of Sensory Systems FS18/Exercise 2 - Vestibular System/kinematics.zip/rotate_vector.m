%ROTATE_VECTOR   Rotates a given column of 3D vectors by a (fixed or variable) quaternion
%	Call: vec_out = rotate_vector(vec_in, q_rot)
%	Input:
% 		vec_in ... 3D vector
%       q_rot ... quaternion describing the rotation
% 		
% 	Output:
%		vec_out ... rotated vector
% 	
%	Formula: vec_out = q_rot * vec_in * q_rot^(-1)
%		where "*" is a quaternion multiplication, and "^(-1)" indicates the
%		inverse.
%
% 	ThH, March-2003
% 	Ver 1.0
% 	***********************************************
%Program Structure:
%\rotate_vector				{in(2): ['vec_in', 'q_rot'], out(1): ['vec_out']}
%	\quat_inv			{in(1): ['q;'], out(1): ['q_inv']}
%		\qconj		{in(1): ['q'], out(1): ['p']}
%	\quatmult			{in(2): ['q', 'r;'], out(1): ['p']}
%*****************************************************************



function vec_out = rotate_vector(vec_in, q_rot)

% Check the input ...
[vec_rows, vec_cols] = size(vec_in);
[quat_rows, quat_cols] = size(q_rot);

% ... 3D vector ....
[vec_rows, vec_cols] = size(vec_in);
if vec_cols ~= 3
	disp(['The 3D vector in ' upper(mfilename) ' must have 3 columns!']);
	vec_out = [];
	return
else	% add a q0-component, for the quaternion multiplication:
	vec_in = [zeros(vec_rows, 1) vec_in];
end

% ... and quaternion:
if quat_cols ~= 3
	disp(['The quaternion in ' upper(mfilename) ' must have 3 columns!']);
	vec_out = [];
	return
end

% If the quaternion is constant for all 3D vectors ...
if quat_rows == 1
	q_rot = repmat(q_rot, vec_rows, 1);
end

% ... or if the 3D-vector is constant for all quaternions:
if vec_rows == 1
	vec_in = repmat(vec_in, quat_rows, 1);
end

% Rotate the vector ...
vec_out = quatmult(q_rot, quatmult(vec_in, quat_inv(q_rot)));

%... and drop the inital "0"
vec_out = vec_out(:,2:4);