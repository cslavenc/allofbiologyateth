%NORMALIZE_V	Normalizes given 3D input vectors.
%
%	ThH, Jan-2006
%	Ver 1.01
% ****************************************************************
%Program Structure:
%\normalize_v				{in(1): ['in_vector'], out(1): ['norm_vector']}
%*****************************************************************


function norm_vector = normalize_v(in_vector)

% Check the input-size:
input_size = size(in_vector);
if ~any(input_size) == 3
   error('NORMALIZE needs an input with 3 columns!');
end

% If you have the input in row-form
if input_size(2) ~= 3 	% if "in_vector" is input as a column-matrix
   in_vector = in_vector';						% transpose it 
   row_flag = 1;
else
   row_flag = 0;
end

% Normalize the vector
vector_length = repmat(sqrt(sum(in_vector.^2,2)),1,3);
norm_vector = zeros(size(in_vector));
index_finite = (vector_length(:,1)~=0);
norm_vector(index_finite,:) = in_vector(index_finite,:) ./ vector_length(index_finite,:);

% Make sure that the output has the correct shape
if row_flag == 1
   norm_vector = norm_vector';
end

% Everything done
