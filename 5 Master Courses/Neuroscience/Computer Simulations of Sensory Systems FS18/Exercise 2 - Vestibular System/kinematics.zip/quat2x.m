%QUAT2X	Conversions from quaternions to other coordinates
%	Call: result = quat2x(quat_in, new_type, [distance])
%	
%	quat_in ... input quaternion (in 3 or 4 columns)
%	new_type ... can be:
%		chair ... Zurich turntable position
%		deg ..... axis angle, i.e. quaternion expressed in degree for each component
%		fick .... Fick angles (in degree)
%		gaze .... normalized gaze vector
%		gimbal .. (Hess-)gimbal angles (in degree)
%		helm .... Helmholz angles (in degree)
%		rot_mat ..... rotation matrix
%		rot_vec ..... rotation vector (returns data as cell-array)
%		screen .. [distance hor ver] projection onto a flat screen. "distance" is required
%		sphere .. [x y z] projection onto sphere. "distance" is required
%		test .... program test. The first value of "data_in" [as quaternion] is used for generation of the test-data
%
% Notes:
% -----------------------------------------------------------------
% Formulas for FICK:
%	Result contains [psi phi theta], in degree,
%		with theta ... horizontal position
%		with phi   ... vertical   position
%		with psi   ... torsional  position
%
%	phi = -asin(R31);
%	theta = asinR21/cos(phi));
%	psi = asin(R32/cos(phi));
%	R_31 = n(1)*n(3) - n(2)*sin(rho) - n(1)*n(3)*cos(rho);
%	R_21 = n(1)*n(2) + n(3)*sin(rho) - n(1)*n(2)*cos(rho);
%	R_32 = n(2)*n(3) + n(1)*sin(rho) - n(2)*n(3)*cos(rho);
%
%	Note that it is assumed that psi < pi;
% -----------------------------------------------------------------
% Formulas for HELM:
%	Result contains [psi phi theta],
%		with theta ... horizontal position
%		with phi   ... vertical   position
%		with psi   ... torsional  position
%
%	theta = asin(R21);
%	phi = -asin(R31/cos(theta));
%	psi = -asin(R23/cos(theta));
%	R_21 = n(1)*n(2) + n(3)*sin(rho) - n(1)*n(2)*cos(rho);
%	R_31 = n(1)*n(3) - n(2)*sin(rho) - n(1)*n(3)*cos(rho);
%	R_23 = n(2)*n(3) - n(1)*sin(rho) - n(2)*n(3)*cos(rho);
%
%	Note that it is assumed that psi < pi;
% -----------------------------------------------------------------
% Formulas for GIMBAL:
%	Result contains [psi phi theta], in degree,
%		with theta ... horizontal position
%		with phi   ... vertical   position
%		with psi   ... torsional  position
%
%	psi   =  asin(R32)
%	phi   = -asin(R31/cos(psi))
%	theta = -asin(R12/cos(psi))
%	R_31 = n(1)*n(3) - n(2)*sin(rho) - n(1)*n(3)*cos(rho);
%	R_12 = n(1)*n(2) - n(3)*sin(rho) - n(1)*n(2)*cos(rho);
%	R_32 = n(2)*n(3) + n(1)*sin(rho) - n(2)*n(3)*cos(rho);
% -----------------------------------------------------------------
% Formulas for CHAIR:
%	Result contains [theta psi theta2], in degree,
%		with theta ... inner position
%		with psi   ... middle   position
%		with theta2   ... outer  position
%
%	theta   =  atan2(R31, R32)
%	psi   = asin(sqrt(R31^2 + R32^2)) * sign(R31*R32)
%	theta2 = asin(R13/sin(psi))
%	R_31 = n(1)*n(3) - n(2)*sin(rho) - n(1)*n(3)*cos(rho);
%	R_32 = n(2)*n(3) + n(1)*sin(rho) - n(2)*n(3)*cos(rho);
%	R_13 = n(1)*n(3) + n(2)*sin(rho) - n(1)*n(3)*cos(rho);
% -----------------------------------------------------------------
% Formulas for ROT_MAT:
%	n ..... normalzed quaternion
%	rho ... size if rotation
%	R(n, rho) = (n*x)n + n^x sin(rho) - n^(n^x)cos(rho)
%
%	ThH, Oct-2003
%	Ver 1.2
% ********************************
%Program Structure:
%\quat2x				{in(3): ['quat_in', 'new_type', 'distance'], out(1): ['Result']}
%	\quat2x>>
%*****************************************************************


function Result = quat2x(quat_in, new_type, distance)

quat.in = quat_in;
clear quat_in;

% Check and adjust the input:
if (size(quat.in,2) ~= 3) & (size(quat.in,2) ~= 4)	% if "quat.in" is input as a column-matrix
	quat.in = quat.in';						% transpose it 
end
if size(quat.in,2) == 4	% if "quat.in" contains 4 values, take only the "vector"
	quat.in = quat.in(:,2:4);
elseif size(quat.in,2) ~= 3
	disp('The quaternions in QUAT2X need to have 3 or 4 elements!');
	return
end

quat.length = sqrt(sum(quat.in.^2,2));
quat.rho = 2*asin(quat.length);					% the size of the rotation

% Find zero-rotations:
quat.iszero = zeros(1, size(quat.in,1));
quat.iszero(quat.rho==0)=1;

% the normalized rotation axis
quat.norm = zeros(size(quat.in, 1), 3);
nz = find(quat.iszero==0);
if ~isempty(nz)
	quat.norm(nz,:) = quat.in(nz,:) ./ (quat.length(nz)*ones(1,3));
end

% Here you can reduce the memory usage
% clear quat.in quat.length nz ....

% Here the conversions take place:
switch new_type
% 	case 'chair'
% 		disp([upper(mfilename) ': Option ' upper(new_type) ' is not implemented. Sorry!']);
% 		Result = [];

	case 'deg'
		Deg = ( 2 * asin(quat.in) * 180/pi);
		Result = Deg;

	case 'fick'
		% Determine the Fick-angles [theta phi psi]:
		Fick = zeros(size(quat.norm));
		Fick(:,2) = -asin(quat.norm(:,1).*quat.norm(:,3) - quat.norm(:,2).*sin(quat.rho) - quat.norm(:,1).*quat.norm(:,3).*cos(quat.rho) );

		Fick(:,3) = asin( (quat.norm(:,1).*quat.norm(:,2) + quat.norm(:,3).*sin(quat.rho) - quat.norm(:,1).*quat.norm(:,2).*cos(quat.rho))./cos(Fick(:,2)) );
		% Check if theta might be larger than pi:
		R22 = quat.norm(:,2).^2 + (quat.norm(:,1).^2 + quat.norm(:,3).^2).*cos(quat.rho);
		large_theta = find(R22<0);
		Fick(large_theta, 1) = pi - Fick(large_theta,1);

		%	psi = asin(R32/cos(phi));
		%	R_32 = n(2)*n(3) + n(1)*sin(quat.rho) - n(2)*n(3)*cos(quat.rho);
		Fick(:,1) = asin((quat.norm(:,2).*quat.norm(:,3) + quat.norm(:,1).*sin(quat.rho) - quat.norm(:,2).*quat.norm(:,3).*cos(quat.rho))./cos(Fick(:,2)) );

		% Conversion to degree:
		Result = Fick*180/pi;

	case 'gaze'
		cr = cos(quat.rho);
		sr = sin(quat.rho);
		Result = [cr + (1-cr).*quat.norm(:,1).^2 ...
				(1-cr).*quat.norm(:,1).*quat.norm(:,2) + sr.*quat.norm(:,3) ...
				(1-cr).*quat.norm(:,1).*quat.norm(:,3) - sr.*quat.norm(:,2)];

	case 'helm'
		% Determine the Helmholtz-angles [theta phi psi]:
		Helm = zeros(size(quat.norm));
		Helm(:,3) = asin(   quat.norm(:,1).*quat.norm(:,2) + quat.norm(:,3).*sin(quat.rho) - quat.norm(:,1).*quat.norm(:,2).*cos(quat.rho) );

		% Check if theta might be larger than pi:
		R22 = quat.norm(:,2).^2 + (quat.norm(:,1).^2 + quat.norm(:,3).^2).*cos(quat.rho);
		large_theta = find(R22<0);
		Helm(large_theta, 1) = pi - Helm(large_theta,1);
		Helm(:,2) = -asin( (quat.norm(:,1).*quat.norm(:,3) - quat.norm(:,2).*sin(quat.rho) - quat.norm(:,1).*quat.norm(:,3).*cos(quat.rho))./cos(Helm(:,3)) );
		Helm(:,1) = -asin( (quat.norm(:,2).*quat.norm(:,3) - quat.norm(:,1).*sin(quat.rho) - quat.norm(:,2).*quat.norm(:,3).*cos(quat.rho))./cos(Helm(:,3)) );

		% Conversion to degree:
		Result = Helm*180/pi;

	case 'gimbal'
		% Determine the Gimbal-angles [theta phi psi]:
		Gimbal= zeros(size(quat.norm));
		Gimbal(:,1) = asin(quat.norm(:,2).*quat.norm(:,3) + quat.norm(:,1).*sin(quat.rho) - quat.norm(:,2).*quat.norm(:,3).*cos(quat.rho));
		Gimbal(:,2) = -asin((quat.norm(:,1).*quat.norm(:,3) - quat.norm(:,2).*sin(quat.rho) - quat.norm(:,1).*quat.norm(:,3).*cos(quat.rho))./cos(Gimbal(:,1)));
		Gimbal(:,3) = -asin((quat.norm(:,1).*quat.norm(:,2) - quat.norm(:,3).*sin(quat.rho) - quat.norm(:,1).*quat.norm(:,2).*cos(quat.rho))./cos(Gimbal(:,1)));

		% Conversion to degree:
		Result = Gimbal*180/pi;

	case 'chair'
		% Determine the ZurichChair-angles [theta psi theta2]:
		Chair= zeros(size(quat.norm));

		R31 = quat.norm(:,1).*quat.norm(:,3) - quat.norm(:,2).*sin(quat.rho) - quat.norm(:,1).*quat.norm(:,3).*cos(quat.rho);
		R32 = quat.norm(:,2).*quat.norm(:,3) + quat.norm(:,1).*sin(quat.rho) - quat.norm(:,2).*quat.norm(:,3).*cos(quat.rho);
		R13 = quat.norm(:,1).*quat.norm(:,3) + quat.norm(:,2).*sin(quat.rho) - quat.norm(:,1).*quat.norm(:,3).*cos(quat.rho);

		Chair(:,1) = atan2(R31, R32);
		Chair(:,2) = asin(sqrt(R31.^2+R32.^2));
		Index.IsMovement_InnerMiddle = find(R31~=0 & R32~=0);
		if ~isempty(Index.IsMovement_InnerMiddle)
			Chair(Index.IsMovement_InnerMiddle,2) = Chair(Index.IsMovement_InnerMiddle,2).* sign(R31(Index.IsMovement_InnerMiddle).*R32(Index.IsMovement_InnerMiddle));
		end
		Index.Move_Outer = find(Chair(:,2)~=0);
		if ~isempty(Index.Move_Outer)
			Chair(Index.Move_Outer,3) = asin(R13(Index.Move_Outer)./sin(Chair(Index.Move_Outer,2)));
		end
		% Conversion to degree:
		Result = Chair*180/pi;

	case 'rot_vec'
		% For rotations by pi (to avoid division by zero):
		length_one = find(quat.length == 1);
		q2rot(length_one) = 0;

		% For the rest....
		not_length_one = find(quat.length ~= 1);

		q2rot(not_length_one) = 1./ sqrt( 1-quat.length(not_length_one).^2 );
		Result = (q2rot' * ones(1,3)) .* quat.in;

	case 'rot_mat'
		Rot_mat = {}
		for ii = 1:size(quat.in, 1)			
			I = eye(3);
			R = zeros(3);			
			for jj = 1:3
				x = I(jj,:);
				n = quat.norm(ii,:);
				rho = quat.rho(ii);
				Rot_mat{ii}(:,jj) = (n*x')*n + (cross(n,x))*sin(rho) - (cross(n,cross(n,x)))*cos(rho);
			end
		end	
		Result = Rot_mat;

	case 'screen'
		if nargin ~= 3
			error([upper(mfilename) ': With the option ' upper(new_type) ' a distance must be given!']);
		end
		quat.gaze = quat2x(quat.in, 'gaze');
		Result = quat.gaze ./(quat.gaze(:,1)*ones(1,3)) * distance;

	case 'sphere'
		if nargin ~= 3
			error([upper(mfilename) ': With the option ' upper(new_type) ' a distance must be given!']);
		end
		Result = quat2x(quat.in, 'gaze') * distance;

	case 'test'
		% The results are tested by converting a number of inputs to the
		% required format

		quat_test = quat.in(1);
		test_in = [quat_test 0 0; ...
				0 quat_test 0; ...
				0 0 quat_test; ...
				0 0 0; ...
				0 quat_test quat_test];
		all_types = {'deg', 'fick', 'gaze', 'helm', 'gimbal', 'rot_mat', 'rot_vec', 'screen', 'sphere'};
		for ii = 1:length(all_types)

			disp('------------------------------');
			disp(all_types{ii});
			if strcmp(all_types{ii}, 'screen')
				distance = 125;
				disp(['Screen distance = ' num2str(distance) ' cm.']);
				eval(['Result = quat2x(test_in, ''' all_types{ii} ''', distance)']);
			elseif strcmp(all_types{ii}, 'sphere')
				distance = 148;
				disp(['Sphere distance = ' num2str(distance) ' cm.']);
				eval(['Result = quat2x(test_in, ''' all_types{ii} ''', distance)']);
			elseif strcmp(all_types{ii}, 'rot_mat')
				eval(['Result = quat2x(test_in, ''' all_types{ii} ''');']);
				for jj = 1:size(test_in, 1)
					disp(Result{jj});
					disp('*****');
				end				
			else
				eval(['Result = quat2x(test_in, ''' all_types{ii} ''')']);
			end			
			pause
		end

	otherwise
		error([' No option ' upper(new_type) ' in ' upper(mfilename)]);
end
