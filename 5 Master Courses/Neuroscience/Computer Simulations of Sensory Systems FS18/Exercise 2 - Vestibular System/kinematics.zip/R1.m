%R1	Rotation matrix for rotation about the x-axis
%	function R = R1(psi)
%
%	This function calculates the active rotation matrix for rotation
%	about e1. 'psi' is entered in radian.
%
%	ThH, Dec-2011
%	Version 1.01
%
%*****************************************************************
%Program Structure:
%\r1				{in(1): ['psi'], out(1): ['R']}
%*****************************************************************

function R = R1(psi)

% convert from degrees into radian:
psi = psi * pi/180;

R = 	[	1			0			0
		0			cos(psi)		-sin(psi)
		0 			sin(psi)		cos(psi) ];
